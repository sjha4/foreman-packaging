__version__ = "0.2.0b1"

default_app_config = 'pulp_2to3_migration.app.Pulp2To3MigrationPluginAppConfig'
